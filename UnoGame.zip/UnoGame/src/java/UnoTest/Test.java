/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UnoTest;

import java.util.ArrayList;
import model.Deck;
import model.Game;
import model.Player;

/**
 *
 * @author preet
 */
public class Test {
     public static void main(String[] args) {
        // TODO code application logic here
   
     Deck uDeck = new Deck();
        Game uGame;
        
        Player p1 = new Player("A001", "First");
        Player p2 = new Player("A002", "Second");
        Player p3 = new Player("A003", "Third");
        Player p4 = new Player("A004", "Fourth");
        Player p5 = new Player("A005", "Fifth");
        
        ArrayList<Player> playerList = new ArrayList<>();
        playerList.add(p1);
        playerList.add(p2);
        playerList.add(p3);
        playerList.add(p4);
        playerList.add(p5);
        
        String gameID = "g001";
        String gameStatus = "Waiting";
        
        uGame = new Game(gameID, playerList, gameStatus, uDeck);
        
        uGame.startPlay();     
        System.out.println(uGame); 
    }
    

}
