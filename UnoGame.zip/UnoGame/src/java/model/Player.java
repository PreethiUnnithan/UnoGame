/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author preet
 */
public class Player {
    private String id;
    private String name;
 
    private ArrayList<Card> cardHold = new ArrayList<>();

    public Player(){
        
    }
    
    public Player(String id, String name) {
        this.id = id;
        this.name = name;
    }
    
    
    public String getId() {
        return id;
    }

   
    public void setId(String id) {
        this.id = id;
    }

    

       public String getName() {
        return name;
    }

    
    public void setName(String name) {
        this.name = name;
    }

            
    public ArrayList<Card> getCardHold() {
        return cardHold;
    }

    
    public void setCardHold(ArrayList<Card> cardHold) {
        this.cardHold = cardHold;
    }

    public void setCardToHand(Card udC){
        this.cardHold.add(udC);
    }  
   
      
  public void getCardFromHand(int i){
      this.cardHold.remove(i);
  }

    @Override
    public String toString() {
        return "Player:" + "id=" + id + ", name=" + name + ", \n\t\tCards in hand:\n\t\t\t" + cardHold + "\n\t" ;
    }
}

    

