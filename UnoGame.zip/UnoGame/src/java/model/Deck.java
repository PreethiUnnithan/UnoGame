/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author preet
 */
public class Deck {
   private final int numOfCard = 108;
    private ArrayList<Card> deck = new ArrayList<Card>();

    public Deck() {
    }
    
     public ArrayList<Card> getDeck() {
        return deck;
    }
    
    public void setDeck(ArrayList<Card> deck) {
        this.deck = deck;
    }
    
    public void setCardToDeck(Card und){
        this.getDeck().add(und);
    }
    
    public Card getCardFromDeck(){
        return this.getDeck().remove(0);
    }
    
   public Deck addDeck(){
        String color[] = {"Red", "Yellow", "Green", "Blue", "RYGB"};
        String type[] = {"Normal","Skip","Reverse","Draw2","Wild", "WildDrawFour"};
        
        Card ucard;
        Deck udeck = new Deck();
        
        for(int c=0; c< color.length; c++){
            int typeIndex = 0;
            
            for(int num=0; num <=12; num++){
                int value = num;
                
                if(num >9){
                    typeIndex++;
                    value=20;
                }
                
                if(c !=4){
                    ucard = new Card(color[c], type[typeIndex], value, color[c]+type[0]+value);
                    udeck.setCardToDeck(ucard);
                    
                    if(num !=0)
                        udeck.setCardToDeck(ucard);
                    
                }
            }
            
            if(c ==4){
                int count = 1;
                while(count <=4){
                    
                    for(int x=4; x < type.length; x++){
                        ucard = new Card(color[c], type[x], 50, color[c]+type[x]+50);
                        udeck.setCardToDeck(ucard);
                    }
                    
                    count++;
                }
            }
        }
        
        return udeck;
    }  

   
    @Override
    public String toString() {
        return "Card on Deck: " + getDeck().size()+"\n"+deck;
    }

  
}
 

