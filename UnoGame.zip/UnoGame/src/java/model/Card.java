/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author preet
 */
public class Card {
    private String cardColor; 
    private String cardType;
    private int cardValue;
    private String cardImage;


    


    @Override
    public String toString() {
        return "UNOcard:" + "cardColor=" + cardColor + ", cardType=" + cardType + ", cardValue=" + cardValue + ", cardImage=" + cardImage + "\n\t\t\t";
    }

    public String getCardColor() {
        return cardColor;
    }

    public void setCardColor(String cardColor) {
        this.cardColor = cardColor;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public int getCardValue() {
        return cardValue;
    }

    public void setCardValue(int cardValue) {
        this.cardValue = cardValue;
    }

    public String getCardImage() {
        return cardImage;
    }

    public void setCardImage(String cardImage) {
        this.cardImage = cardImage;
    }
    public Card(String cardColor, String cardType, int cardValue, String cardImage) {
        this.cardColor = cardColor;
        this.cardType = cardType;
        this.cardValue = cardValue;
        this.cardImage = cardImage;


}
}
