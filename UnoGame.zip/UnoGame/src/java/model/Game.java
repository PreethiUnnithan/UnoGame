/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author preet
 */
public class Game {
     private String gameID;
    private ArrayList<Player> playerList ;
    private String gameStatus; 
    private Deck deck;   
    private Card disPile;

    public Game(String gameID, ArrayList<Player> playerList, String gameStatus, Deck deck) {
        this.gameID = gameID;
        this.playerList = playerList;
        this.gameStatus = gameStatus;
        this.deck = deck;
    }
    
   
    public String getGameID() {
        return gameID;
    }

    public void setGameID(String gameID) {
        this.gameID = gameID;
    }

    public ArrayList<Player> getPlayerList() {
        return playerList;
    }

    public void setPlayerList(ArrayList<Player> playerList) {
        this.playerList = playerList;
    }

    public String getGameStatus() {
        return gameStatus;
    }

      
    public Deck getDeck() {
        return deck;
    }

    
    public void setDeck(Deck Deck) {
        this.deck = Deck;
    }
    
       public void setGameStatus(String gameStatus) {
        this.gameStatus = gameStatus;
    }

   
    
    public void setPlayer(Player player){
        this.playerList.add(player);
    }
    
    public void getPlayer(){
        
    }

    public Card getDisPile() {
        return disPile;
    }

    public void setDisPile(Card disPile) {
        this.disPile = disPile;
    }
     
    
     public Deck ShuffleDeck(Deck udDeck)
     {
         Collections.shuffle(udDeck.getDeck());
         return udDeck;
     }
 
     public void startPlay(){
         deck = this.ShuffleDeck(deck.addDeck());
         
         int count = 1; 
         while(count <=7){
             for(Player player : playerList){
                 Card handCard = deck.getCardFromDeck();
                 player.setCardToHand(handCard);
             }
             
             count++;
         }
         disPile = deck.getCardFromDeck();
     }   
    
    @Override
    public String toString() {
        return "Game ID=" + gameID + "\nDiscard Card=" + disPile + "\nGameStatus=" + gameStatus + "\n" + deck + "\n\t" + playerList;
    }

 
}


